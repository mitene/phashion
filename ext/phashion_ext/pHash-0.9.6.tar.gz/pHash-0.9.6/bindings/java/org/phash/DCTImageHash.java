package org.phash;
public class DCTImageHash extends ImageHash
{
	public long hash;
}
