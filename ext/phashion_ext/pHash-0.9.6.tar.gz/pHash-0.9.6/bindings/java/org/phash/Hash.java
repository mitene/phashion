package org.phash;
public abstract class Hash
{
	protected String filename;
	public String getFilename() { return filename; }
}
