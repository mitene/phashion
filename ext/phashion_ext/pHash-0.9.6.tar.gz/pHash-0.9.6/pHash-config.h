/* pHash-config.h.  Generated from pHash-config.h.in by configure.  */
/* configure with audio hash */
#define HAVE_AUDIO_HASH 1

/* configure with video hash */
#define HAVE_VIDEO_HASH 1

/* configure with image hash */
#define HAVE_IMAGE_HASH 1

/* configure with pthread support */
#define HAVE_PTHREAD 1
